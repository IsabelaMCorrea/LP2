﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pcalc
{
    public partial class Form1 : Form
    {
        double numero1, numero2, resultado; //globais

        private void TxtN1_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(txtN1.Text, out numero1))
            {
                MessageBox.Show("Número 1 inválido!");
                txtN1.Focus();
            }
        }

        private void TxtN2_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(txtN2.Text, out numero2))
            {
                MessageBox.Show("Número 2 inválido!");
                txtN2.Focus();
            }
        }

        private void BtnSoma_Click(object sender, EventArgs e)
        {
            resultado = numero1 + numero2;
            txtResultado.Text = resultado.ToString();
        }

        private void BtnSub_Click(object sender, EventArgs e)
        {
            resultado = numero1 - numero2;
            txtResultado.Text = resultado.ToString();
        }

        private void BtnMult_Click(object sender, EventArgs e)
        {
            resultado = numero1 * numero2;
            txtResultado.Text = resultado.ToString();
        }

      

        private void BtnDiv_Click(object sender, EventArgs e)
        {
            if (numero2 == 0)
            {
                MessageBox.Show("Não pode dividir por zero!!!", "Erro",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtN2.Focus();
            }
            else
            {
                resultado = numero1 / numero2;
                txtResultado.Text = resultado.ToString();
            }
        }

        private void BtnSair_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Você deseja sair mesmo?",
                "Saída", MessageBoxButtons.YesNo,
                MessageBoxIcon.Question)==
                DialogResult.Yes)
            {
                Close();
            }
        }

        public Form1()
        {
            InitializeComponent();
        }

        private void BtnLimpar_Click(object sender, EventArgs e)
        {
            txtN1.Text = "";
            txtN2.Text = "";
            txtResultado.Text = "";
            //volta para o numero 1 e limpa variaveis
            txtN1.Focus();
            resultado = 0;
            numero1 = 0;
            numero2 = 0;

        }
    }
}
