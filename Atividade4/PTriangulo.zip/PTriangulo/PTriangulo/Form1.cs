﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PTriangulo
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void txtValorA_Validated(object sender, EventArgs e)
        {
            errorProvider1.SetError(txtValorA, "");
            double valorA;

            if (!double.TryParse(txtValorA.Text, out valorA))
            {
                errorProvider1.SetError(txtValorA, "Valor de A inválido");
                txtValorA.Focus();
            }
            else
                errorProvider1.Clear();
        }

        private void txtValorB_Validated(object sender, EventArgs e)
        {
            errorProvider2.SetError(txtValorB, "");
            double valorB;

            if (!double.TryParse(txtValorB.Text, out valorB))
            {
                errorProvider2.SetError(txtValorB, "Valor de B inválido");
                txtValorB.Focus();
            }
        }

        private void txtValorC_Validated(object sender, EventArgs e)
        {
            errorProvider3.SetError(txtValorC, "");
            double valorC;

            if (!double.TryParse(txtValorC.Text, out valorC))
            {
                errorProvider3.SetError(txtValorC, "Valor de C inválido");
                txtValorC.Focus();
            }
        }

        private void btnExecutar_Click(object sender, EventArgs e)
        {
            double valorA, valorB, valorC;

            if (!double.TryParse(txtValorA.Text, out valorA) ||
                    !double.TryParse(txtValorB.Text, out valorB) ||
                    !double.TryParse(txtValorC.Text, out valorC))
            {
                MessageBox.Show("Valores devem ser númericos");
            }
            else

                if (valorA < (valorB + valorC) &&
                    valorA > Math.Abs(valorB - valorC) &&
                    valorB < (valorA + valorC) &&
                    valorB > Math.Abs(valorA - valorC) &&
                    valorC < (valorA + valorB) &&
                    valorC > Math.Abs(valorA - valorB))
            {
                if (valorA == valorB && valorB == valorC)
                {
                    txtResultado.Text = "Equilátero";
                    MessageBox.Show($"Os valores {valorA}, {valorB}, e {valorC} formam um triângulo equilátero");

                }

                else
                {
                    if (valorA == valorB || valorA == valorC || valorC == valorB)
                    {
                        txtResultado.Text = "Isósceles";
                        MessageBox.Show($"Os valores {valorA}, {valorB} e {valorC} formam um triângulo isósceles");
                    }
                    else
                    {
                        txtResultado.Text = "Escaleno";
                        MessageBox.Show($"Os valores {valorA}, {valorB} e {valorC} formam um triângulo escaleno");
                    }
                }

            }
            else

                MessageBox.Show($"Os valores {valorA}, {valorB} e {valorC} NÃO formam um triângulo");
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtValorA.Clear();
            txtValorB.Clear();
            txtValorC.Clear();
            txtResultado.Clear();
         
        }
    }
}
