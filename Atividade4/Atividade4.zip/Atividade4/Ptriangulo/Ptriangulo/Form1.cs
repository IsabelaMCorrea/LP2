﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ptriangulo
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void TxtMedida1_Validated(object sender, EventArgs e)
        {
            errorProvider1.SetError(txtValorA, "");
            double valorA;

            if (!double.TryParse(txtValorA.Text, out valorA))
            {
                errorProvider1.SetError(txtValorA, "Valor de A inválido");
            }
        }

        private void TxtValorB_Validated(object sender, EventArgs e)
        {
            errorProvider2.SetError(txtValorB, "");
            double valorB;

            if (!double.TryParse(txtValorB.Text, out valorB))
            {
                errorProvider2.SetError(txtValorB, "Valor de B inválido");
            }
        }

        private void TxtValorC_Validated(object sender, EventArgs e)
        {
            errorProvider3.SetError(txtValorC, "");
            double valorC;

            if (!double.TryParse(txtValorC.Text, out valorC))
            {
                errorProvider3.SetError(txtValorC, "Valor de C inválido");
            }
        }

        private void Button1_Click(object sender, EventArgs e)
        {
            double valorA, valorB, valorC;

            //testar se os valores são validos
            if (!double.TryParse(txtValorA.Text, out valorA) ||
                    !double.TryParse(txtValorB.Text, out valorB) ||
                    !double.TryParse(txtValorC.Text, out valorC))
            {
                MessageBox.Show("Valores devem ser númericos");
            }
            else

                if (valorA < (valorB + valorC) &&
                    valorA > Math.Abs(valorB - valorC) &&
                    valorB < (valorA + valorC) &&
                    valorB > Math.Abs(valorA - valorC) &&
                    valorC < (valorA + valorB) &&
                    valorC > Math.Abs(valorA - valorB))
            {
                if (valorA == valorB && valorB == valorC)
                {
                    txtResultado.Text = "Isósceles";
                    MessageBox.Show($"Os valores {valorA}, {valorB}, e {valorC} formam um triângulo isósceles");
               
            }

            else
            {
                    if (valorA == valorB || valorA == valorC || valorC == valorB)
                    {
                        txtResultado.Text = "Equilátero";
                        MessageBox.Show($"Os valores {valorA}, {valorB} e {valorC} formam um triângulo equilátero");
                    }
                    else
                    {
                        txtResultado.Text = "Escaleno";
                        MessageBox.Show($"Os valores {valorA}, {valorB} e {valorC} formam um triângulo escaleno");
                    }
                    }

                }
                else
                    
                    MessageBox.Show($"Os valores {valorA}, {valorB} e {valorC} NÃO formam um triângulo");
            
        }

        private void Button2_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
    

