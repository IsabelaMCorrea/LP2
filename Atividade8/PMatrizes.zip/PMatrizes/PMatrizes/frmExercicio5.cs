﻿using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Security.Permissions;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PMatrizes
{
    public partial class frmExercicio5 : Form
    {
        public frmExercicio5()
        {
            InitializeComponent();
        }

        private void btnVerificar_Click(object sender, EventArgs e)
        {
            string[,] respostas = new string[4, 10];
            string[] gabarito = { "A", "B", "E", "C", "D", "B", "C", "A", "D", "E" };

            lstbxGabarito.Items.Clear();

            for (int i = 0; i < 4; i++)
            {
                string resultado = $"Aluno {i + 1}: ";

                for (int j = 0; j < 10; j++)
                {
                    string resposta = Interaction.InputBox
                        ($"Aluno {i+1} - Questão {j+1} (A-E):").ToUpper();

                    if (resposta == "A" || resposta == "B" || resposta == "C" || resposta == "D"
                        || resposta == "E")
                    {
                        respostas[i, j] = resposta;

                        if (resposta == gabarito[j])
                        {
                            lstbxGabarito.Items.Add($"O aluno {i + 1} acertou a questão {j + 1}, era {gabarito[j]} e escolheu {resposta}");
                        }
                        else
                        {
                            lstbxGabarito.Items.Add($"O aluno {i + 1} errou a questão {j + 1}, era {gabarito[j]} e escolheu {resposta}");
                        }
                    }
                    else
                    {
                        MessageBox.Show("Resposta inválida!");
                        j--;
                    }                  
                }
            }
        }
    }
}
