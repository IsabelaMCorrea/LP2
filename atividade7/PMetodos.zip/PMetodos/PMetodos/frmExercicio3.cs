﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PMetodos
{
    public partial class frmExercicio3 : Form
    {
        public frmExercicio3()
        {
            InitializeComponent();
        }

        private void Label1_Click(object sender, EventArgs e)
        {

        }

        private void TxtPalavra1_TextChanged(object sender, EventArgs e)
        {

        }

        private void BtnRemover1_Click(object sender, EventArgs e)
        {
           int posicao = txtPalavra2.Text.IndexOf(txtPalavra1.Text, 
               StringComparison.OrdinalIgnoreCase);

            //a        a        ss
            //casa    Fatec    assessoria
            //c       F        a

            while (posicao >= 0)
            {
                txtPalavra2.Text = txtPalavra2.Text.Substring(0, posicao) +
                    txtPalavra2.Text.Substring(posicao + txtPalavra1.Text.Length,
                    txtPalavra2.Text.Length - posicao - txtPalavra1.Text.Length);

                posicao = txtPalavra2.Text.IndexOf(txtPalavra1.Text,
               StringComparison.OrdinalIgnoreCase);
            }
        }
    }
}
