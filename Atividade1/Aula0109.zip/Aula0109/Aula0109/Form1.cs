﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Aula0109
{
    public partial class Form1 : Form
    {
        Double raio;
        Double altura;
        double volume;


        public Form1()
        {
            InitializeComponent();
        }

 
        


        private void TextRaio_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(txtRaio.Text, out raio))
            {
                MessageBox.Show("Raio inválido!");
                txtRaio.Focus();
            }
            else
            {
                if (raio<=0)
                {
                    MessageBox.Show("Raio deve ser maior que zero!");
                    txtRaio.Focus();
                }
            }
        }

        private void TextAltura_Validating(object sender, CancelEventArgs e)
        {
            if(!double.TryParse(txtAltura.Text, out altura))
            {
                MessageBox.Show("Altura inválida!");
                e.Cancel = true;
            }
            else
            {
                if(altura<=0)
                {
                    MessageBox.Show("Altura deve ser maior que zero!");
                    e.Cancel = true;
                }
            }
        }

        private void BtnFechar_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void BtnLimpar_Click(object sender, EventArgs e)
        {
            //limpar os dados
            txtAltura.Clear();
            txtRaio.Text = "";
            txtVolume.Text = "";
            //txtVolume.Text = String.Empty;

            txtRaio.Focus();
        }

        private void BtnCalcular_Click(object sender, EventArgs e)
        {
            volume = Math.PI * Math.Pow(raio, 2) * altura;
            txtVolume.Text = volume.ToString("N2");
        }

        private void TxtVolume_TextChanged(object sender, EventArgs e)
        {
            txtVolume.Text = volume.ToString("N2");
        }
    }
    }

