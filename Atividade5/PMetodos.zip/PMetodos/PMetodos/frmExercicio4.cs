﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PMetodos
{
    public partial class frmExercicio4 : Form
    {
        public frmExercicio4()
        {
            InitializeComponent();
        }

        private void btnContaNumeros_Click(object sender, EventArgs e)
        {
            int contador = 0;
            int contaNum = 0;

            while (contador < rchtxtFrase.Text.Length)
            {
                if (char.IsNumber(rchtxtFrase.Text[contador]))
                {
                    contaNum++;
                }
                
                contador++; //contador+=1
            }
            MessageBox.Show($"O texto tem {contaNum} números");
        }

        private void btnLocalizaBranco_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < rchtxtFrase.Text.Length; i++)
            {
                if (Char.IsWhiteSpace(rchtxtFrase.Text[i]))
                {
                    MessageBox.Show($"A posição do 1° caracter branco é {i + 1}");
                    break;
                }
            }
        }

        private void btnContaLetras_Click(object sender, EventArgs e)
        {
            int contaLetra = 0;
            foreach (char c in rchtxtFrase.Text)
            {
                if (char.IsLetter(c))
                {
                    contaLetra++;
                }
            }

            MessageBox.Show($"O texto tem {contaLetra} letras");
        }
    }

}
