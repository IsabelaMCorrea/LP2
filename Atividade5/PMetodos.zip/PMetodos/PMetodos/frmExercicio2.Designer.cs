﻿namespace PMetodos
{
    partial class frmExercicio2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtPalavra1 = new System.Windows.Forms.TextBox();
            this.txtPalavra2 = new System.Windows.Forms.TextBox();
            this.btnVerificaIguais = new System.Windows.Forms.Button();
            this.btnInsereNo2 = new System.Windows.Forms.Button();
            this.btnInsereNo1 = new System.Windows.Forms.Button();
            this.lblPalavra1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // txtPalavra1
            // 
            this.txtPalavra1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPalavra1.Location = new System.Drawing.Point(194, 43);
            this.txtPalavra1.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.txtPalavra1.Name = "txtPalavra1";
            this.txtPalavra1.Size = new System.Drawing.Size(160, 29);
            this.txtPalavra1.TabIndex = 0;
            // 
            // txtPalavra2
            // 
            this.txtPalavra2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPalavra2.Location = new System.Drawing.Point(194, 84);
            this.txtPalavra2.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.txtPalavra2.Name = "txtPalavra2";
            this.txtPalavra2.Size = new System.Drawing.Size(160, 29);
            this.txtPalavra2.TabIndex = 1;
            // 
            // btnVerificaIguais
            // 
            this.btnVerificaIguais.Location = new System.Drawing.Point(45, 183);
            this.btnVerificaIguais.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnVerificaIguais.Name = "btnVerificaIguais";
            this.btnVerificaIguais.Size = new System.Drawing.Size(124, 39);
            this.btnVerificaIguais.TabIndex = 2;
            this.btnVerificaIguais.Text = "Verificar igualdade";
            this.btnVerificaIguais.UseVisualStyleBackColor = true;
            this.btnVerificaIguais.Click += new System.EventHandler(this.btnVerificaIguais_Click);
            // 
            // btnInsereNo2
            // 
            this.btnInsereNo2.Location = new System.Drawing.Point(205, 183);
            this.btnInsereNo2.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnInsereNo2.Name = "btnInsereNo2";
            this.btnInsereNo2.Size = new System.Drawing.Size(124, 39);
            this.btnInsereNo2.TabIndex = 3;
            this.btnInsereNo2.Text = "Inserir 1° no meio do 2°";
            this.btnInsereNo2.UseVisualStyleBackColor = true;
            this.btnInsereNo2.Click += new System.EventHandler(this.button2_Click);
            // 
            // btnInsereNo1
            // 
            this.btnInsereNo1.Location = new System.Drawing.Point(363, 183);
            this.btnInsereNo1.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnInsereNo1.Name = "btnInsereNo1";
            this.btnInsereNo1.Size = new System.Drawing.Size(124, 39);
            this.btnInsereNo1.TabIndex = 4;
            this.btnInsereNo1.Text = "Inserir 2 * no meio do 1°";
            this.btnInsereNo1.UseVisualStyleBackColor = true;
            this.btnInsereNo1.Click += new System.EventHandler(this.btnInsereNo1_Click);
            // 
            // lblPalavra1
            // 
            this.lblPalavra1.AutoSize = true;
            this.lblPalavra1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPalavra1.Location = new System.Drawing.Point(104, 46);
            this.lblPalavra1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblPalavra1.Name = "lblPalavra1";
            this.lblPalavra1.Size = new System.Drawing.Size(86, 24);
            this.lblPalavra1.TabIndex = 5;
            this.lblPalavra1.Text = "Palavra 1";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(104, 87);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(86, 24);
            this.label2.TabIndex = 6;
            this.label2.Text = "Palavra 2";
            // 
            // frmExercicio2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(534, 306);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.lblPalavra1);
            this.Controls.Add(this.btnInsereNo1);
            this.Controls.Add(this.btnInsereNo2);
            this.Controls.Add(this.btnVerificaIguais);
            this.Controls.Add(this.txtPalavra2);
            this.Controls.Add(this.txtPalavra1);
            this.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Name = "frmExercicio2";
            this.Text = "frmExercicio2";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtPalavra1;
        private System.Windows.Forms.TextBox txtPalavra2;
        private System.Windows.Forms.Button btnVerificaIguais;
        private System.Windows.Forms.Button btnInsereNo2;
        private System.Windows.Forms.Button btnInsereNo1;
        private System.Windows.Forms.Label lblPalavra1;
        private System.Windows.Forms.Label label2;
    }
}