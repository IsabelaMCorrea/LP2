﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace PVendas01
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnVerificar_Click(object sender, EventArgs e)
        {
            double[,] vendas = new double[3, 4];
            string auxiliar = "";
            double total;
            double totalGeral;

            totalGeral = 0;

            for (int i = 0; i < 3; i++)
            {
                total = 0;

                for (int j = 0; j < 4; j++)
                {
                    auxiliar = Interaction.InputBox($"Digite o total vendido na semana {j + 1} do mês {i + 1}",
                        "Entrada de dados");

                    if (!Double.TryParse(auxiliar, out vendas[i, j]) ||
                        vendas[i, j] < 0)
                    {
                        MessageBox.Show("Dados inválidos");
                        j--;
                    }
                    else
                    {
                        lstbxVendas.Items.Add($"Total do mês: {i + 1} Semana: {j + 1} {auxiliar}");
                        total += vendas[i, j];
                        totalGeral += vendas[i, j];
                    }
                }
                lstbxVendas.Items.Add($"Total mês: {total}");
            }

            lstbxVendas.Items.Add($"Total Geral: {totalGeral}");
        }

        /*professora não consegui fazer funcionar o "N2" para formatar as casas decimais
        e não consegui pular linha :( */

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            lstbxVendas.Items.Clear();
        }
    }
}
